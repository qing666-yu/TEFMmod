import struct
import time
import os

# ================= 配置区 =================
SO_FILE = "libmy_first_mod.so"
OUTPUT_FILE = "my_first_mod.tefpkg"
PKG_ID = "com.QEllipsis.myfirstmod"  # 刚才你写在C代码里的包名
# ==========================================

MAGIC = 0x50464554
VERSION = 0x0200
COMPRESS_NONE = 0x00

def main():
    if not os.path.exists(SO_FILE):
        print(f"错误：找不到文件 {SO_FILE}，请确认你在正确的目录下")
        return

    with open(SO_FILE, "rb") as f:
        so_data = f.read()

    file_count = 1
    data_size = len(so_data)
    
    # 1. 构造文件条目 (tefpkg_entry_t, 共34字节)
    # 格式: 索引(4), 数据偏移(4), 压缩大小(4), 原始大小(4), 校验和(8), 时间戳(8), 压缩类型(1), 压缩级别(1)
    timestamp = int(time.time())
    entry_data = struct.pack(
        "<IIIIQQBB",
        0,              # index
        0,              # data_offset (从数据区开始算，这是第一个文件，所以是0)
        data_size,      # compressed_size
        data_size,      # original_size
        0,              # checksum (暂时填0，如果加载器报校验失败，我们再改)
        timestamp,      # timestamp
        COMPRESS_NONE,  # compress_type
        0               # compress_level
    )
    
    # 2. 计算数据区偏移量 (文件头 52字节 + 条目表 34字节)
    header_size = 52
    entry_size = 34
    data_offset = header_size + (file_count * entry_size)

    # 3. 构造文件头 (tefpkg_header_t, 共52字节)
    # 格式: 魔数(4), 版本(2), 文件数(2), 预留条目数(2), 保留(2), 数据偏移(4), 数据大小(4), 时间戳(8), 校验和(8), 内容哈希(8), 签名(8)
    header_data = struct.pack(
        "<IHHHHIIQQQQ",
        MAGIC,          # magic "TEFP"
        VERSION,        # version
        file_count,     # file_count
        0,              # reserved_entries
        0,              # _reserved
        data_offset,    # data_offset
        data_size,      # data_size
        timestamp,      # timestamp
        0,              # checksum (头部校验和)
        0,              # content_hash (内容完整性)
        0               # signature (签名，不设防暂时留空)
    )

    # 4. 写入 .tefpkg 文件
    with open(OUTPUT_FILE, "wb") as f:
        f.write(header_data)
        f.write(entry_data)
        f.write(so_data)

    print(f"打包成功！生成文件: {OUTPUT_FILE}")

if __name__ == "__main__":
    main()
